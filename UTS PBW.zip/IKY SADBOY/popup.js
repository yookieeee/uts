document.addEventListener("DOMContentLoaded", function () {
    let pageTitle = document.title;
    let message = "";

    if (pageTitle.includes("Beranda")) {
        message = "Selamat datang di Beranda!";
    } else if (pageTitle.includes("Portofolio")) {
        message = "Selamat datang di Portofolio!";
    } else if (pageTitle.includes("Prestasi")) {
        message = "Selamat datang di Prestasi!";
    } else if (pageTitle.includes("Contact")) {
        message = "Selamat datang di Halaman Kontak!";
    }

    if (message) {
        alert(message);
    }
});
